package com.example.autoclicker;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.List;

public class AutoClickService extends AccessibilityService {
    private static final String TAG = "AutoClickService";
    private static AutoClickService instance;
    private boolean isRunning = false;
    private Handler handler = new Handler(Looper.getMainLooper());
    private List<ClickPoint> clickPoints = new ArrayList<>();
    private int currentPointIndex = 0;
    private int repeatCount = 1;
    private int currentRepeat = 0;
    private long interval = 1000; // 默认间隔1秒

    public static AutoClickService getInstance() {
        return instance;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // 处理辅助功能事件
    }

    @Override
    public void onInterrupt() {
        Log.d(TAG, "服务中断");
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        Log.d(TAG, "服务创建");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        instance = null;
        stopAutoClick();
        Log.d(TAG, "服务销毁");
    }

    /**
     * 设置点击点列表
     */
    public void setClickPoints(List<ClickPoint> points) {
        this.clickPoints = points;
        this.currentPointIndex = 0;
        this.currentRepeat = 0;
    }

    /**
     * 设置重复次数
     */
    public void setRepeatCount(int count) {
        this.repeatCount = count;
        this.currentRepeat = 0;
    }

    /**
     * 设置点击间隔（毫秒）
     */
    public void setInterval(long interval) {
        this.interval = interval;
    }

    /**
     * 开始自动点击
     */
    public void startAutoClick() {
        if (clickPoints.isEmpty()) {
            Log.e(TAG, "没有设置点击点");
            return;
        }

        if (isRunning) {
            Log.w(TAG, "自动点击已在运行中");
            return;
        }

        isRunning = true;
        currentPointIndex = 0;
        currentRepeat = 0;
        
        Log.d(TAG, "开始自动点击");
        performNextClick();
    }

    /**
     * 停止自动点击
     */
    public void stopAutoClick() {
        isRunning = false;
        handler.removeCallbacksAndMessages(null);
        Log.d(TAG, "停止自动点击");
    }

    /**
     * 执行下一个点击
     */
    private void performNextClick() {
        if (!isRunning) {
            return;
        }

        if (currentPointIndex >= clickPoints.size()) {
            currentPointIndex = 0;
            currentRepeat++;
            
            if (currentRepeat >= repeatCount) {
                Log.d(TAG, "自动点击完成");
                stopAutoClick();
                return;
            }
        }

        ClickPoint point = clickPoints.get(currentPointIndex);
        performClick(point.x, point.y);
        
        currentPointIndex++;
        
        // 安排下一次点击
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                performNextClick();
            }
        }, interval);
    }

    /**
     * 执行点击操作
     */
    public boolean performClick(float x, float y) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Path path = new Path();
            path.moveTo(x, y);
            
            GestureDescription.Builder builder = new GestureDescription.Builder();
            builder.addStroke(new GestureDescription.StrokeDescription(path, 0, 100));
            
            GestureDescription gesture = builder.build();
            boolean result = dispatchGesture(gesture, null, null);
            
            if (result) {
                Log.d(TAG, "点击成功: (" + x + ", " + y + ")");
            } else {
                Log.e(TAG, "点击失败: (" + x + ", " + y + ")");
            }
            
            return result;
        }
        return false;
    }

    /**
     * 执行滑动操作
     */
    public boolean performSwipe(float startX, float startY, float endX, float endY, long duration) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Path path = new Path();
            path.moveTo(startX, startY);
            path.lineTo(endX, endY);
            
            GestureDescription.Builder builder = new GestureDescription.Builder();
            builder.addStroke(new GestureDescription.StrokeDescription(path, 0, duration));
            
            GestureDescription gesture = builder.build();
            return dispatchGesture(gesture, null, null);
        }
        return false;
    }

    /**
     * 执行长按操作
     */
    public boolean performLongClick(float x, float y, long duration) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Path path = new Path();
            path.moveTo(x, y);
            
            GestureDescription.Builder builder = new GestureDescription.Builder();
            builder.addStroke(new GestureDescription.StrokeDescription(path, 0, duration));
            
            GestureDescription gesture = builder.build();
            return dispatchGesture(gesture, null, null);
        }
        return false;
    }

    /**
     * 查找指定文本的节点
     */
    public AccessibilityNodeInfo findNodeByText(String text) {
        AccessibilityNodeInfo rootNode = getRootInActiveWindow();
        if (rootNode == null) {
            return null;
        }

        List<AccessibilityNodeInfo> nodes = rootNode.findAccessibilityNodeInfosByText(text);
        if (!nodes.isEmpty()) {
            return nodes.get(0);
        }

        return null;
    }

    /**
     * 查找指定ID的节点
     */
    public AccessibilityNodeInfo findNodeById(String viewId) {
        AccessibilityNodeInfo rootNode = getRootInActiveWindow();
        if (rootNode == null) {
            return null;
        }

        List<AccessibilityNodeInfo> nodes = rootNode.findAccessibilityNodeInfosByViewId(viewId);
        if (!nodes.isEmpty()) {
            return nodes.get(0);
        }

        return null;
    }

    /**
     * 点击指定节点
     */
    public boolean clickNode(AccessibilityNodeInfo node) {
        if (node == null) {
            return false;
        }

        Rect bounds = new Rect();
        node.getBoundsInScreen(bounds);
        float x = bounds.centerX();
        float y = bounds.centerY();
        
        return performClick(x, y);
    }

    /**
     * 获取屏幕尺寸
     */
    public int[] getScreenSize() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            return new int[]{
                getDisplay().getRealMetrics(new android.util.DisplayMetrics()).widthPixels,
                getDisplay().getRealMetrics(new android.util.DisplayMetrics()).heightPixels
            };
        }
        return new int[]{1080, 1920}; // 默认值
    }

    /**
     * 检查服务是否正在运行
     */
    public boolean isServiceRunning() {
        return isRunning;
    }

    /**
     * 点击点数据类
     */
    public static class ClickPoint {
        public float x;
        public float y;
        public String description;

        public ClickPoint(float x, float y, String description) {
            this.x = x;
            this.y = y;
            this.description = description;
        }
    }
}